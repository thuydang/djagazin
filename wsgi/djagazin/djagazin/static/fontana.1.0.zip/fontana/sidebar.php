<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package aThemes
 */
?>
<div id="widget-area-2" class="site-sidebar widget-area" role="complementary">
	<?php if ( ! dynamic_sidebar( 'sidebar-1' ) ) : ?>
	<?php endif; ?>
<!-- #widget-area-2 --></div>